require('dotenv').config()
const passport = require("passport")
const Registeration = require("../models/registeration.model")
const { v4: uuidv4 } = require('uuid');

const GoogleStrategy = require('passport-google-oauth20').Strategy;

passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: "http://localhost:6600/auth/google/callback"
  },
  async function(accessToken, refreshToken, profile, cb) {
    let registeration = await Registeration.findOne({email : profile?._json?.email})
    if(!registeration)
    {
      registeration = await Registeration.create({
        email : profile._json.email,
        password : uuidv4()
      })
    }
    console.log(registeration)
    return cb(null, registeration);
  }
));


module.exports=passport;