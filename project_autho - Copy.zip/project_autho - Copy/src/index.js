const express = require("express");
const app = express();
require('dotenv').config()
const PORT = process.env.PORT || 8000

console.log(process.env.PORT)
app.use(express.json());
var jwt = require('jsonwebtoken');
const connect =require("./configs/db")
const cors = require("cors");
app.use(cors());
const passport = require("./configs/google-outh")
const { v4: uuidv4 } = require('uuid');

const registerationControl = require("./controls/registeration.control");
app.use("/registeration" , registerationControl);

const loginControl = require("./controls/login.control");
app.use("/login" , loginControl)

const productControl = require("./controls/product.control");
app.use("/products" , productControl)


app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/login' , session : false }),
  function(req, res) {
    const token = generateToken(req.user)
    return res.status(200).send({registeration : req.user, token , error:false})

  });


  const generateToken = (registeration)=>{
    return jwt.sign({ registeration }, process.env.KEY);
}


app.listen(PORT ,async()=>{
    try{
        await connect();
        console.log(`${PORT}`)
    }
    catch(err)
    {
        console.log(err.message);
    }

})